# AI-Mario-Game
  
Juego de Mario AI  
  
10-02-2022  
Modificación de elementos en pantalla y dentro del juego.  
Sustitución de 3 recursos visuales.  
  
Los cambios sólo se reflejan en GitHub Pages.  
